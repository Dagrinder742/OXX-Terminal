#!/usr/bin/env python3
"""
Tests for sandbox_tool.py. Runs entirely in a throwaway temp folder.
Usage:  python tests/test_sandbox_tool.py      (exit code 1 on any failure; the last line is ALL OK when everything passes)
"""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(tempfile.mkdtemp(prefix="sbx_test_"))
DEAD_URL = "http://127.0.0.1:9/v1/chat/completions"  # nothing listens here
os.environ["LLAMA_URL"] = DEAD_URL
SB = ROOT / "tools"
SB.mkdir()
os.environ["SANDBOX_DIR"] = str(SB)
os.environ["AUDIT_LOG"] = str(SB.parent / "refused_test.log")
sys.path.insert(0, str(HERE.parent / "src"))
import sandbox_tool as T  # noqa: E402
_REAL_ASK = T.ask_model
T.REQUIRE_VERIFY = False  # older agent tests script a bare write->DONE; the gate has its own tests below

bad = 0


def check(ok, kind, what, detail=""):
    global bad
    print(("PASS " if ok else "FAIL ") + f"{kind:9}", what, ("-> " + detail) if detail else "")
    bad += not ok


def first(s):
    return s.splitlines()[0] if s else ""


(SB / "_t.txt").write_text("hello world\nTODO: fix\n")
(SB / "long.txt").write_text("".join(f"line {i}\n" for i in range(1, 301)))
(SB / "wide.txt").write_text("x" * 5000 + "\n" + "y" * 5000 + "\n" + "z\n")
(ROOT / "outside.txt").write_text("SECRET\n")
os.symlink(ROOT, SB / "_link")  # points outside the sandbox
esc = ROOT / "_escape_probe"

# ---- CLI policy (same attack list as before) --------------------------------
strict = [
    "rm -rf .", "chmod 777 _t.txt", "bash -c id", "python3 -c 1",
    "cat a | rm b", "cat > out.txt", "cat /etc/passwd", "cat ../../.bashrc",
    "cat /etc/*", "cat ../*", "cat -- /etc/passwd", "cat _link/outside.txt", "ls _link",
    "grep foo /etc/passwd", "grep -rf /etc/passwd x .", "grep -Rn foo .",
    "grep --fil=/etc/passwd x", "grep --file /etc/passwd x", "grep -e foo /etc/passwd",
    "grep -A3 foo /etc/passwd", "grep --regexp foo /etc/passwd", "grep --bogus foo .",
    "sed -n p /etc/hosts", "sed -f /etc/passwd _t.txt", "sed -nf /etc/passwd _t.txt",
    "sed --expression=p /etc/passwd", "sed --expr=p /etc/passwd", "sed -ne p /etc/hosts",
    "sed -i s/a/b/ /etc/hosts", "tail -f _t.txt", "tail -fn 1 _t.txt", "tail --foll _t.txt",
    "head -n 5 /etc/passwd", "wc --files0-from=/etc/passwd", "ls --bogus",
]
for c in strict:
    out = T.run(c)
    check(out.startswith("REFUSED"), "refuse", c, first(out))

for c in ["sed 'e id' _t.txt", "sed 'r /etc/hosts' _t.txt", f"sed 'w {esc}' _t.txt",
          f"sed 's/hello/x/w {esc}' _t.txt", "sed 's/hello/x/e' _t.txt",
          "cat a; rm b", "cat $(id)"]:
    out = T.run(c)
    check(out.startswith("REFUSED") or "[exit 0]" not in out, "harmless", c, first(out))
check(not esc.exists(), "escape", "nothing written outside sandbox")

for c in ["cat _t.txt", "cat _t*.txt", "grep -n TODO _t.txt", "grep -rn hello .",
          "grep -ie todo _t.txt", "sed -n 's/hello/bye/p' _t.txt", "ls -la", "ls -R",
          "head -n 1 _t.txt", "tail -n 1 _t.txt", "wc -l _t.txt"]:
    check(T.run(c).startswith("[exit 0]"), "allow", c)

# ---- read_file --------------------------------------------------------------
check(T.run("read_file /etc/passwd").startswith("REFUSED"), "refuse", "read_file /etc/passwd")
check(T.run("read_file ../x").startswith("REFUSED"), "refuse", "read_file ../x")
check(T.run("read_file _link/outside.txt").startswith("REFUSED"), "refuse", "read_file via symlink")
check(T.run("read_file nope.txt").startswith("REFUSED"), "refuse", "read_file missing file")
out = T.run("read_file long.txt 1 50")
check("lines 1-50 of 300" in out and "250 more lines" in out
      and "read_file long.txt 51 50" in out, "readfile", "header + continue hint", first(out))
out = T.run("read_file long.txt 51 50")
check("lines 51-100 of 300" in out and "  51 | line 51" in out, "readfile", "continuation range")
out = T.run("read_file long.txt 290 50")
check("lines 290-300 of 300" in out and "more lines" not in out, "readfile", "last page has no hint")
check(T.run("read_file long.txt 999").startswith("ERROR"), "readfile", "start past end")
out = T.run("read_file wide.txt 1 3")
check(len(out) < T.MAX_OUTPUT + 400 and "more lines not shown" in out,
      "readfile", "char cap truncates wide files and offers continuation", f"{len(out)} chars")

# ---- write_file / patch_file / protected files ------------------------------
for c in ["write_file /etc/x hi", "write_file ../x hi", "write_file _link/pwn.txt hi",
          "patch_file /etc/hosts a b", "patch_file ../x a b"]:
    check(T.run(c).startswith("REFUSED"), "refuse", c)
check(not (ROOT / "pwn.txt").exists(), "escape", "symlink write did not land outside")
check(T.run("write_file new.txt hello").startswith("[exit 0]")
      and (SB / "new.txt").read_text() == "hello", "write", "write inside sandbox")
check("new.txt (created)" in (SB / "file_index.txt").read_text(), "write", "index logged")
(SB / "dup.txt").write_text("a\nb\na\nb\n")
check("not unique" in T.run("patch_file dup.txt a x"), "patch", "non-unique search refused")
check("not found" in T.run("patch_file dup.txt zzz x"), "patch", "missing search refused")
check(T.run("patch_file _t.txt hello bye").startswith("[exit 0]")
      and "bye world" in (SB / "_t.txt").read_text(), "patch", "unique patch applied")

guard = SB / "guarded.py"
guard.write_text("# policy\n")
T.PROTECTED.add(guard.resolve())
for c in ["write_file guarded.py x", "patch_file guarded.py policy x",
          "sed -i s/policy/x/ guarded.py", "sed -ni s/policy/x/p guarded.py",
          "sed --in-place s/policy/x/ guarded.py", "sed --in-pl s/policy/x/ guarded.py",
          "sed -i.bak s/policy/x/ g*.py"]:
    check(T.run(c).startswith("REFUSED"), "protected", c)
check(guard.read_text() == "# policy\n", "protected", "guarded file unchanged")
check(T.run("cat guarded.py").startswith("[exit 0]"), "protected", "protected file is still readable")
check(T.run("sed -i s/hello/hi/ _t.txt").startswith("[exit 0]"), "protected", "sed -i on normal file ok")

# ---- agent output handling --------------------------------------------------
kind, text, _b, _n = T.parse_reply("DONE: Intro:\n\n1. one\n2. two")
check(kind == "done" and text == "Intro:\n\n1. one\n2. two", "parse", "multi-line DONE kept whole")
check(T.parse_reply("CMD: read_file a.py 1 75") == ("cmd", "read_file a.py 1 75", "", []), "parse", "CMD")
check(T.parse_reply("I think we should look") == (None, "", "", []), "parse", "no marker")
check(T.parse_reply("NOTE: it prints 6.50\nCMD: DONE")[:2] == ("done", "it prints 6.50"), "parse", "bare 'CMD: DONE' is a DONE; the answer is the last NOTE")
check(T.parse_reply("CMD: done.")[:2] == ("done", "(finished)"), "parse", "'CMD: done.' without a note is accepted too")
check(T.parse_reply("CMD: DONEFOO")[0] == "cmd" and T.parse_reply("CMD: DONE now")[0] == "cmd", "parse", "'CMD: DONE...' followed by other text is NOT treated as DONE")

# ---- runaway NOTE (wordcount retest: "NOTE: wc.py: 1, 2, 3 ... 195" cost 640 s per reply) ----
_loop = "NOTE: wc.py: " + ", ".join(str(i) for i in range(1, 196))
check(len(_loop) > 2 * T.NOTE_MAX_CHARS and T._runaway_note("CMD: x\n" + _loop), "note", "a runaway NOTE line is detected")
check(not T._runaway_note("NOTE: short and fine"), "note", "a normal NOTE is not flagged")
check(not T._runaway_note("CMD: write_file a.py\n```python\n" + _loop), "note", "a long NOTE: line INSIDE a code fence is file content, not flagged")
_n = T.parse_reply("CMD: write_file wc.py\n```python\nx = 1\n```\n\n" + _loop)
check(_n[0] == "cmd" and _n[1] == "write_file wc.py" and "x = 1" in _n[2], "note", "a reply with a runaway NOTE still parses its command and block")
check(all(len(x) <= T.NOTE_MAX_CHARS + 4 for x in T.parse_reply("NOTE: " + "9, " * 400 + "\nCMD: ls")[3]), "note", "notes are cut to NOTE_MAX_CHARS")
check(T.parse_reply("NOTE: found it in line 3\nCMD: ls")[3] == ["found it in line 3"], "note", "a normal note is unchanged")
_hl = T._clean_reply("CMD: write_file a.py\n```python\nNOTE: " + "7, " * 200 + "\n```\n" + _loop, "cmd", "write_file a.py", [])
check(len(_hl.splitlines()[2]) > T.NOTE_MAX_CHARS and len(_hl.splitlines()[-1]) <= T.NOTE_MAX_CHARS + 4,
      "note", "history keeps file content intact but cuts the NOTE line after the block")
_consumed = [0]
def _fake_sse():
    yield 'data: {"choices":[{"delta":{"content":"NOTE: wc.py: "}}]}'
    for i in range(5000):
        _consumed[0] += 1
        yield 'data: {"choices":[{"delta":{"content":"%d, "}}]}' % i
_txt, _np, *_ = T._read_sse(_fake_sse(), show_progress=False)
check(_consumed[0] < 600 and _txt.startswith("NOTE:"), "note", "the stream is stopped early on a runaway NOTE", f"read {_consumed[0]} of 5000 pieces")
_ok = ['data: {"choices":[{"delta":{"content":"CMD: ls"}}]}', "data: [DONE]"]
check(T._read_sse(_ok, show_progress=False)[0] == "CMD: ls", "note", "a normal streamed reply is unchanged")
check(T.parse_reply("NOTE: imports at 1-9\nCMD: read_file a.py 76 75")
      == ("cmd", "read_file a.py 76 75", "", ["imports at 1-9"]), "parse", "NOTE before CMD")
check(T.parse_reply("CMD: ls\nNOTE: late note")[3] == ["late note"], "parse", "NOTE after plain CMD")
k, t, b, n = T.parse_reply("NOTE: real\nCMD: write_file a.md\n```md\nNOTE: not a note\n```")
check(n == ["real"] and b.startswith("```md"), "parse", "NOTE inside file content is not a note")

# ---- block input: write_file / patch_file -----------------------------------
code = 'print("a\\nb")\nx = "tab\\there"'          # contains literal backslash-n / backslash-t
body = "```python\n" + code + "\n```\nthanks"
check(T.run("write_file blk.py", body).startswith("[exit 0]")
      and (SB / "blk.py").read_text() == code + "\n", "block", "write_file keeps literal \\n exactly")
md = "# T\n```python\nx = 1\n```\nend"
check(T.run("write_file doc.md", "```md\n" + md + "\n```").startswith("[exit 0]")
      and (SB / "doc.md").read_text() == md + "\n", "block", "content may contain inner fences")
# model keeps writing after its closing fence and invents tool output / more steps (seen in run10 run 8)
tail = ("\nNOTE: read_file skill.py 1 1\nCMD: check_file skill.py\n```plaintext\nNo problems found.\n```\n"
        "\nNOTE: x\nCMD: run_python skill.py\n```plaintext\nfake output\n```\n\nDONE: The code works.")
r = T.run("write_file tail1.py", "```python\n" + code + "\n```" + tail)
check(r.startswith("[exit 0]") and (SB / "tail1.py").read_text() == code + "\n",
      "block", "invented steps after the closing fence are not written into the file")
r = T.run("write_file tail2.py", "```python\n" + code + "\n```\n\nDONE: The code works.")
check(r.startswith("[exit 0]") and (SB / "tail2.py").read_text() == code + "\n",
      "block", "DONE after the closing fence is not written into the file")
md2 = "# T\n```python\nx = 1\n```\nmiddle\n```sh\nls\n```\nend"
r = T.run("write_file doc2.md", "```md\n" + md2 + "\n```" + tail)
check(r.startswith("[exit 0]") and (SB / "doc2.md").read_text() == md2 + "\n",
      "block", "inner fences kept AND invented tail dropped")
# the exact reply shape from the phone: write block, then invented check_file/run_python steps
k, txt, bd, _n = T.parse_reply("NOTE: read_file skill.py 1 1\nCMD: write_file skill.py\n```python\nx = 1\n```\n"
                               "\nNOTE: read_file skill.py 1 1\nCMD: check_file skill.py\n```plaintext\nNo problems found.\n```\n")
check(k == "cmd" and txt == "write_file skill.py" and T._fenced_block(bd) == "x = 1\n",
      "block", "parse_reply + _fenced_block take only the first block")
# ---- missing stdlib import (run10: NameError for `random` killed 3 of 20 runs) ----------
_noimp = "class Skill:\n    def go(self):\n        return random.randint(1, 3)\n"
_p = T.check_python(_noimp)
check(len(_p) == 1 and "random" in _p[0] and "FIRST line" in _p[0] and "class Skill:" in _p[0] and _p[0].startswith("line 3:"),
      "import", "missing `import random` is reported with the line and a ready patch", str(_p)[:120])
check(T.check_python("import random\nclass A:\n    def f(self):\n        return random.random()\n") == [],
      "import", "no warning when the import is there")
check(T.check_python("import os.path\nx = os.getcwd()\n") == [], "import", "import os.path counts as os")
check(T.check_python("def f(time):\n    return time.sleep\n") == [], "import", "a parameter named like a module is not flagged")
check(T.check_python("string = object()\nprint(string.x)\n") == [], "import", "an assigned name is not flagged")
check(T.check_python("from random import randint\nprint(random.x)\n") != [], "import",
      "`from random import randint` does not import `random`")
check(len(T.check_python("class A:\n  def f(self):\n    return random.x + time.y + random.z\n")) == 2,
      "import", "two missing modules reported once each")
(SB / "imp.py").write_text(_noimp)
_r = T.run("check_file imp.py")
check("never imported" in _r, "import", "check_file shows it")
_r = T.run("patch_file imp.py", "<<<<<<< SEARCH\nclass Skill:\n=======\nimport random\n\nclass Skill:\n>>>>>>> REPLACE\n")
check(_r.startswith("[exit 0]") and "no problems" in _r and (SB / "imp.py").read_text().startswith("import random\n\nclass Skill:"),
      "import", "the ready-made patch from the hint works and clears the problem", _r[:120])

# ---- patch_file never turns a working .py file into a broken one (run10: file wrecked in 3 runs) ----
(SB / "wreck.py").write_text('class A:\n    def __init__(self):\n        self.s = {\n            "a": 1,\n            "b": 2\n        }\n')
_orig = (SB / "wreck.py").read_text()
_r = T.run("patch_file wreck.py", "<<<<<<< SEARCH\n        self.s = {\n=======\n        self.s = {}\n>>>>>>> REPLACE\n")
check(_r.startswith("REFUSED") and "syntax error" in _r and "NOT applied" in _r and (SB / "wreck.py").read_text() == _orig,
      "patchguard", "a patch that breaks the syntax is refused and the file is unchanged", _r[:100])
_r = T.run("patch_file wreck.py", "<<<<<<< SEARCH\n            \"b\": 2\n=======\n            \"b\": 3\n>>>>>>> REPLACE\n")
check(_r.startswith("[exit 0]") and '"b": 3' in (SB / "wreck.py").read_text(), "patchguard", "a good patch still applies")
(SB / "broken.py").write_text("def f(:\n    pass\n")
_r = T.run("patch_file broken.py", "<<<<<<< SEARCH\ndef f(:\n=======\ndef f(x):\n>>>>>>> REPLACE\n")
check(_r.startswith("[exit 0]") and (SB / "broken.py").read_text().startswith("def f(x):"),
      "patchguard", "an already-broken file can still be repaired", _r[:100])
(SB / "notes.txt").write_text("a {\n")
_r = T.run("patch_file notes.txt", "<<<<<<< SEARCH\na {\n=======\nb (\n>>>>>>> REPLACE\n")
check(_r.startswith("[exit 0]"), "patchguard", "non-.py files are not syntax-checked")
# the exact bad patch from run10 (import placed inside the dict)
(SB / "run3.py").write_text('class Skill:\n    def perceive(self):\n        m = {\n            "t": random.randint(1, 2),\n        }\n        return m\n')
_r = T.run("patch_file run3.py", '<<<<<<< SEARCH\n"t": random.randint(1, 2),\n=======\nimport random\n"t": random.randint(1, 2),\n>>>>>>> REPLACE\n')
check(_r.startswith("REFUSED") and "import random" not in (SB / "run3.py").read_text(), "patchguard",
      "the real run-3 patch (import inside a dict) is refused", _r[:90])
check(T.run("write_file cut.py", "```python\nprint('unfinished'").startswith("REFUSED")
      and not (SB / "cut.py").exists(), "block", "unclosed block (cut-off reply) is not written")
check(T.run("write_file nofence.py", "just prose").startswith("REFUSED"), "block", "no block, no content")
check(T.run(r"write_file inl.py print('a\nb')").startswith("REFUSED")
      and not (SB / "inl.py").exists(), "block", "inline content with \\n refused, not corrupted")
check(T.run("write_file ../x.py", "```\nx\n```").startswith("REFUSED"), "block", "block write outside sandbox")
check(T.run("write_file guarded.py", "```\nx\n```").startswith("REFUSED"), "block", "block write to protected file")
check(T.run("write_file __pycache__/m.pyc", "```\nx\n```").startswith("REFUSED"), "block", "__pycache__ refused")

(SB / "p.py").write_text('def f():\n    print("a\\nb")\n    return 1\n')
sr = '<<<<<<< SEARCH\n    print("a\\nb")\n=======\n    print("a\\nb\\nc")\n>>>>>>> REPLACE'
check(T.run("patch_file p.py", sr).startswith("[exit 0]")
      and (SB / "p.py").read_text() == 'def f():\n    print("a\\nb\\nc")\n    return 1\n',
      "block", "patch_file SEARCH/REPLACE keeps literal \\n")
check(T.run("patch_file p.py", "```\n" + sr + "\n```").startswith("REFUSED"),
      "block", "fenced patch with stale SEARCH is refused")
fenced = '```\n<<<<<<< SEARCH\n    return 1\n=======\n    return 2\n>>>>>>> REPLACE\n```'
check(T.run("patch_file p.py", fenced).startswith("[exit 0]") and "return 2" in (SB / "p.py").read_text(),
      "block", "patch block wrapped in a fence")
check("empty" in T.run("patch_file p.py", "<<<<<<< SEARCH\n=======\nx\n>>>>>>> REPLACE"),
      "block", "empty SEARCH refused")
check(T.run("patch_file p.py", "<<<<<<< SEARCH\nx\n=======\ny").startswith("REFUSED"),
      "block", "malformed block refused")
check(T.run("patch_file guarded.py", "<<<<<<< SEARCH\npolicy\n=======\nx\n>>>>>>> REPLACE").startswith("REFUSED"),
      "block", "patch to protected file refused")
# run bugfix/1-3 shapes: identical SEARCH/REPLACE with the new code AFTER the >>>>>>> line,
# and several blocks in one reply
(SB / "bf.py").write_text("def average(numbers):\n    return 1\n\n\ndef median(numbers):\n    return 2\n")
_bf_before = (SB / "bf.py").read_text()
_r = T.run("patch_file bf.py", "<<<<<<< SEARCH\ndef average(numbers):\n=======\ndef average(numbers):\n>>>>>>> REPLACE\n    if not numbers:\n        return 0.0\n")
check(_r.startswith("REFUSED") and "INSIDE the block" in _r and (SB / "bf.py").read_text() == _bf_before,
      "block", "new code after >>>>>>> REPLACE: refused with a hint, file unchanged", _r[:90])
_r = T.run("patch_file bf.py", "<<<<<<< SEARCH\ndef average(numbers):\n=======\ndef average(numbers):\n>>>>>>> REPLACE\n")
check(_r.startswith("REFUSED") and "INSIDE the block" not in _r, "block",
      "identical SEARCH/REPLACE with nothing after it keeps the plain message", _r[:90])
_two = ("<<<<<<< SEARCH\n    return 1\n=======\n    return 10\n>>>>>>> REPLACE\n\n"
        "CMD: patch_file bf.py\n<<<<<<< SEARCH\n    return 2\n=======\n    return 20\n>>>>>>> REPLACE\n")
_r = T.run("patch_file bf.py", _two)
check(_r.startswith("REFUSED") and "ONE patch_file per reply" in _r and (SB / "bf.py").read_text() == _bf_before,
      "block", "two blocks in one reply: refused, nothing applied", _r[:90])
_r = T.run("patch_file bf.py", "<<<<<<< SEARCH\n    return 1\n=======\n    return 10\n>>>>>>> REPLACE\n\nNOTE: next I patch median\nDONE: ok\n")
check(_r.startswith("[exit 0]") and "return 10" in (SB / "bf.py").read_text(), "block",
      "one good block followed only by NOTE:/DONE: lines still applies", _r[:90])

# ---- agent loop with a scripted fake model ----------------------------------
import io
from contextlib import redirect_stdout
scripted = iter([
    "NOTE: plan: create then read back\nCMD: write_file out.py\n```python\nprint('a\\nb')\n```",
    "CMD: read_file out.py",
    "NOTE: out.py is a 1-line print\nCMD: ls",
    "NOTE: done\nDONE: all good\nsecond line",
])
seen = []
T.ask_model = lambda msgs: (seen.append([m for m in msgs]), next(scripted))[1]
buf = io.StringIO()
with redirect_stdout(buf):
    answer = T.agent("make and check out.py")
check(answer == "all good\nsecond line", "agent", "multi-line DONE returned", repr(answer))
check((SB / "out.py").read_text() == "print('a\\nb')\n", "agent", "block write executed end to end")
last_user = lambda i: [c for r, c in seen[i] if r == "user"][-1]
check("Reminder" not in last_user(1), "agent", "no nudge after a reply that had a NOTE")
check("Reminder" in last_user(2), "agent", "nudge after a reply without a NOTE")
check("final>" not in buf.getvalue(), "agent", "no duplicate final> line")
T.ask_model = lambda msgs: "ERROR: Failed to connect to local llama-server: refused"
check(T.agent("x").startswith("(stopped: ERROR: Failed to connect"), "agent", "server down stops immediately")

# Replay of a real Termux session: block placed BEFORE the CMD line, then "CMD: DONE: ..."
check(T.parse_reply("NOTE: saved\nCMD: DONE: Successfully wrote x\nsecond")
      == ("done", "Successfully wrote x\nsecond", "", ["saved"]), "parse", "'CMD: DONE: ...' is treated as DONE")
(SB / "hello_test.py").unlink(missing_ok=True)
scripted = iter([
    'NOTE: Created it:\n```python\nprint("a\\nb")\n```\nCMD: write_file hello_test.py',
    'NOTE: retry\nCMD: write_file hello_test.py\n```python\nprint("a\\nb")\n```',
    "NOTE: saved\nCMD: DONE: Successfully wrote hello_test.py",
])
calls = []
T.ask_model = lambda msgs: (calls.append(list(msgs)), next(scripted))[1]
with redirect_stdout(io.StringIO()):
    answer = T.agent("create hello_test.py")
check(answer == "Successfully wrote hello_test.py" and len(calls) == 3, "replay", "finishes in 3 steps", f"{len(calls)} calls")
check((SB / "hello_test.py").read_text() == 'print("a\\nb")\n', "replay", "file content correct")
r = subprocess.run([sys.executable, str(SB / "hello_test.py")], capture_output=True, text=True)
check(r.stdout == "a\nb\n", "replay", "written script prints a and b on separate lines", repr(r.stdout))
refusal = [c for role, c in calls[1] if role == "user"][-1]
check("AFTER the CMD line" in refusal, "replay", "refusal tells the model where the block goes")
check("run_python hello_test.py" in [c for role, c in calls[2] if role == "user"][-1],
      "replay", "after writing a .py the model is told to run_python it")

# A model that keeps repeating a finished write must not re-run it
(SB / "again.py").unlink(missing_ok=True)
w = "NOTE: n\nCMD: write_file again.py\n```python\nx = 1\n```"
steps = iter([w, w, w, "DONE: finished"])
def fake(msgs):
    reply = next(steps)
    if len([1 for r_, _ in msgs if r_ == "assistant"]) == 1:   # after the 1st write succeeded
        (SB / "again.py").write_text("x = 'edited outside the agent'\n")
    return reply
T.ask_model = fake
with redirect_stdout(io.StringIO()):
    answer = T.agent("write again.py")
check((SB / "again.py").read_text() == "x = 'edited outside the agent'\n", "replay",
      "repeated identical write is not re-run")
check(answer.startswith("(stopped: aborted due to consecutive failures)") or answer == "finished",
      "replay", "repeat loop is cut short", answer)
T.PREVIEW_LINES = 5
pv = T._preview("\n".join(str(i) for i in range(20)))
check(pv.count("\n") == 5 and "15 more lines were sent to the model" in pv, "preview", "display capped")
T.PREVIEW_LINES = 0
check(T._preview("a\n" * 50) == "a\n" * 50, "preview", "PREVIEW_LINES=0 shows all")

# ---- stdlib shadowing: a model-written json.py must not run -----------------
shadow = ROOT / "shadow"
shadow.mkdir()
shutil.copy(HERE.parent / "src" / "sandbox_tool.py", shadow / "sandbox_tool.py")
os.chmod(shadow / "sandbox_tool.py", 0o644)  # the real file may be locked; test an unlocked copy
(shadow / "json.py").write_text("print('PWNED_BY_SHADOW')\nraise SystemExit(3)\n")
r = subprocess.run([sys.executable, "sandbox_tool.py", "ls"], cwd=shadow, capture_output=True,
                   text=True, env={**os.environ, "SANDBOX_DIR": str(shadow)})
check("PWNED_BY_SHADOW" not in r.stdout + r.stderr and r.returncode == 0,
      "shadow", "script-dir json.py is not imported", f"exit {r.returncode}")

# ---- check_file: static check, never executes -------------------------------
V1 = """class Skill:
    def perceive(self):
        # Implement perception logic here
        pass
"""
V2 = """class Skill:
    def __init__(self):
        self.reason = None
        self.think = None

    def reason(self):
        self.reason = "x"

    def think(self):
        self.reason()
"""
V3 = """import random

class Skill:
    def __init__(self):
        self.state = {}

    def evaluate(self, actions):
        return max(actions)

    def think(self):
        self.evaluate()

skill = Skill()
skill.think()
"""
GOOD = T.SYSTEM.split("CMD: write_file stock.py\n```python\n")[1].split("\n```")[0]
p1, p2, p3 = T.check_python(V1), T.check_python(V2), T.check_python(V3)
check(any("no real logic" in x for x in p1) and any("placeholder comment" in x for x in p1),
      "check", "stub body and placeholder comment found (your first run)", str(p1))
check(any("replaces the method" in x for x in p2), "check", "attribute shadowing a method found (your second run)", str(p2))
check(any("takes 1" in x and "0 argument" in x for x in p3), "check", "wrong argument count found", str(p3))
check(any("runs when the file is imported" in x for x in p3), "check", "demo code outside __main__ guard found")
check(T.check_python(GOOD) == [], "check", "the worked example in SYSTEM passes its own check", str(T.check_python(GOOD)))
check(T.check_python('print("a\\nb")\n') == [], "check", "plain one-line script is not flagged")
se = T.check_python("def f(:\n    pass\n")
check(len(se) == 1 and se[0].startswith("SYNTAX ERROR line 1"), "check", "syntax error reported with line", str(se))
check(T.check_python("class A:\n    def f(self, a, b=1, *c): pass\n    def g(self): self.f(1); self.f(1, 2, 3, 4)\n") != [] and
      not any("argument" in x for x in T.check_python("class A:\n    def f(self, a, b=1, *c): return a\n    def g(self): self.f(1); self.f(1, 2, 3, 4)\n")),
      "check", "defaults and *args are respected (no false positive)")
check(not T.check_python("class A:\n    @property\n    def x(self): return 1\n    def set(self): self.y = 2\n"),
      "check", "decorated methods and unrelated attributes not flagged")

(SB / "bad.py").write_text(V2)
(SB / "ok.py").write_text(GOOD + "\n")
r = T.run("check_file bad.py")
check(r.startswith("[exit 0]") and "problem(s) found" in r, "check", "check_file reports problems", first(r))
r = T.run("check_file ok.py")
check("no problems found" in r and "NOT executed" in r, "check", "clean file says it was not executed")
check(T.run("check_file _t.txt").startswith("REFUSED: check_file only checks .py"), "check", "non-.py refused")
check(T.run("check_file ../outside.txt").startswith("REFUSED"), "check", "outside path refused")
check(T.run("check_file nope.py").startswith("ERROR: no such file"), "check", "missing file reported")
check(T.run("check_file").startswith("REFUSED: usage"), "check", "missing argument refused")
marker_file = SB / "ran.flag"
(SB / "evil.py").write_text(f"open({str(marker_file)!r}, 'w').write('x')\n")
T.run("check_file evil.py")
check(not marker_file.exists(), "check", "check_file never executes the file")
r = T.run("write_file auto.py", "```python\n" + V2 + "```")
check(r.startswith("[exit 0]") and "Successfully wrote auto.py" in r and "problem(s) found" in r,
      "check", "write_file of a .py reports problems automatically", first(r))
r = T.run("write_file notes.txt", "```\nTODO later\n```")
check("[check]" not in r, "check", "non-.py writes are not checked")
r = T.run("patch_file auto.py", "<<<<<<< SEARCH\n        self.reason = None\n=======\n        self.reason_text = None\n>>>>>>> REPLACE")
check("Successfully patched" in r or r.startswith("[exit 0]"), "check", "patch applies", first(r))
check("[check]" in r, "check", "patch_file of a .py also reports", r.splitlines()[-1][:60])

# agent: a failed check blocks the 'already done' shortcut and the model gets fix guidance
scripted = iter([
    "NOTE: writing\nCMD: write_file sk.py\n```python\n" + V2 + "```",
    "NOTE: fixing\nCMD: patch_file sk.py\n<<<<<<< SEARCH\n        self.reason = None\n=======\n        self.reason_v = None\n>>>>>>> REPLACE",
    "NOTE: done\nDONE: wrote and patched sk.py",
])
calls = []
T.ask_model = lambda msgs: (calls.append(list(msgs)), next(scripted))[1]
with redirect_stdout(io.StringIO()):
    answer = T.agent("write sk.py")
last_user = [c for role, c in calls[1] if role == "user"][-1]
check("check found problems" in last_user and "Fix them with patch_file" in last_user,
      "check", "agent tells the model to fix reported problems", last_user.splitlines()[-1][:70])
check(answer == "wrote and patched sk.py", "check", "agent still finishes normally")

# ---- run_python: guarded execution ------------------------------------------
import time
T.RUN_TIMEOUT_S = 2
T.RUN_MEM_MB = 256
(SB / "guard.py").write_text("# protected\n")
_saved_protected = T.PROTECTED
T.PROTECTED = {(SB / "guard.py").resolve()}
(SB / "victim.txt").write_text("keep me\n")
MK = ROOT / "marker"  # a path outside the sandbox that nothing may create


def rp(name, code, timeout=None):
    (SB / f"{name}.py").write_text(code)
    t0 = time.time()
    r = T.run(f"run_python {name}.py")
    return r, time.time() - t0


r, _ = rp("rp_ok", "print('hello'); open('rp_made.txt','w').write('x'); print(open('rp_made.txt').read())")
check(r.startswith("[exit 0]") and "hello" in r and (SB / "rp_made.txt").read_text() == "x", "run", "runs, writes inside the sandbox", first(r))
r, _ = rp("rp_tb", "def f(): return 1/0\nf()")
check(r.startswith("[exit 1]") and "ZeroDivisionError" in r and "rp_tb.py" in r and "runpy" not in r and "<string>" not in r,
      "run", "traceback comes back, without the tool's own frames")
r, _ = rp("rp_syn", "def f(:\n")
check("SyntaxError" in r, "run", "syntax error is reported")
r, _ = rp("rp_in", "input()")
check("EOFError" in r, "run", "input() fails fast instead of hanging")
(SB / "rp_sib.py").write_text("V = 7\n")
r, _ = rp("rp_imp", "import rp_sib; print(rp_sib.V)")
check("7" in r and r.startswith("[exit 0]"), "run", "a script can import its sibling modules", first(r))
(SB / "json.py").write_text("raise SystemExit('SHADOWED')\n")
r, _ = rp("rp_shadow", "import json; print(json.dumps({'a': 1}))")
os.remove(SB / "json.py")
check('{"a": 1}' in r and "SHADOWED" not in r, "run", "a model-written json.py cannot shadow the stdlib", first(r))

# pre-flight scan (friendly refusal, nothing runs)
for label, code in [("os.system", "import os\nos.system('touch %s')" % MK),
                    ("from-import alias", "from os import system as s\ns('touch %s')" % MK),
                    ("import subprocess", "import subprocess\nsubprocess.run(['touch', '%s'])" % MK),
                    ("pathlib chmod", "from pathlib import Path\nPath('victim.txt').chmod(0o777)")]:
    r, _ = rp("rp_scan", code)
    check(r.startswith("REFUSED: not run") and not MK.exists(), "run", f"pre-scan refuses {label}", first(r))

# runtime enforcement: things the scan cannot see
def blocked(label, code, marker=None, word="sandbox:"):
    r, _ = rp("rp_b", code)
    ok = word in r and "[exit 1]" in r and (marker is None or not marker.exists())
    check(ok, "run", f"runtime blocks {label}", first(r) + " | " + r.strip().splitlines()[-1][:90])

blocked("obfuscated os.system", "getattr(__import__('o'+'s'), 'sys'+'tem')('touch %s')" % MK, MK)
blocked("subprocess via __import__", "__import__('subprocess').run(['touch', '%s'])" % MK, MK)
blocked("os.exec", "import os\ngetattr(os, 'ex'+'ecv')('/usr/bin/touch', ['touch', '%s'])" % MK, MK)
blocked("os.fork", "import os\ngetattr(os, 'fo'+'rk')()")
blocked("multiprocessing", "import multiprocessing")
blocked("low-level fork_exec", "import _posixsubprocess as p\np.fork_exec([b'/usr/bin/touch', b'%s'], [b'/usr/bin/touch'], True, (), None, None, -1,-1,-1,-1,-1,-1,-1,-1, False, False, -1, None, None, None, -1, None)" % MK, MK)
blocked("reading a file outside", "print(open(%r).read())" % str(ROOT / "outside.txt"))
blocked("reading /etc/passwd", "print(open('/etc/passwd').read())")
blocked("listing / ", "import os\nprint(os.listdir('/'))")
blocked("writing outside", "open(%r, 'w').write('x')" % str(MK))
blocked("'..' relative paths", "print(open('../outside.txt').read())")
blocked("dir_fd '..' trick (read)",
        "import os\nos.makedirs('rp_a/b/c', exist_ok=True)\nfd = os.open('.', os.O_RDONLY)\nos.chdir('rp_a/b/c')\n"
        "print(os.read(os.open('../outside.txt', os.O_RDONLY, dir_fd=fd), 50))")
blocked("moving a file outside", "import os\nos.rename('rp_made.txt', %r)" % str(MK), MK)
blocked("deleting a file", "import os\nos.remove('victim.txt')")
blocked("deleting with pathlib", "from pathlib import Path\nPath('victim.txt').unlink()")
blocked("rmtree", "import shutil\nshutil.rmtree('rp_a')")
blocked("chmod", "import os\ngetattr(os, 'chm'+'od')('victim.txt', 0o777)")
blocked("symlink", "import os\ngetattr(os, 'sym'+'link')('/etc/passwd', 'rp_link')")
blocked("network", "import socket\nsocket.create_connection(('127.0.0.1', 9), 1)", word="network access")
blocked("ctypes loading libc", "__import__('ctypes').CDLL(None)")
r, _ = rp("rp_ct", "c = __import__('ctypes')\nprint('pythonapi =', c.pythonapi)")
check("pythonapi = None" in r or ("SandboxBlocked" in r and "ctypes" in r), "run",
      "ctypes cannot be used (import fails, or pythonapi is None; it differs by platform)", first(r) + " " + r.splitlines()[-1][:60])
_roots = T._read_roots()
_bad = [r for r in _roots if r in ("/", "/usr", "/usr/local") or r == os.path.realpath(sys.prefix)
        or r == os.path.realpath(sys.base_prefix) or str(ROOT).startswith(r + os.sep) or r == str(ROOT)]
check(_roots and not _bad, "run", "read roots are Python's library folders, never a whole prefix or the test area", f"{_bad or _roots}")
check(all(r.count(os.sep) >= 3 or "zoneinfo" in r for r in _roots), "run", "no read root is a shallow top-level folder", str(_roots))
blocked("gc introspection", "import gc\ngc.get_objects()")
blocked("sqlite outside", "import sqlite3\nsqlite3.connect(%r)" % str(MK))
blocked("writing the protected file", "open('guard.py', 'w').write('x')")
blocked("renaming over the protected file", "import os\nos.rename('rp_made.txt', 'guard.py')")
check((SB / "victim.txt").exists() and (SB / "guard.py").read_text() == "# protected\n" and not (SB / "rp_link").exists()
      and oct((SB / "victim.txt").stat().st_mode & 0o777) != "0o777", "run", "victim, guard and permissions untouched afterwards")
r, _ = rp("rp_tmp", "import tempfile, shutil\nwith tempfile.TemporaryFile() as f: f.write(b'x')\nd = tempfile.mkdtemp(); shutil.rmtree(d); print('tmp ok')")
check("tmp ok" in r, "run", "tempfile and cleanup of the run's own temp folder work", first(r))
r, _ = rp("rp_db", "import sqlite3\nc = sqlite3.connect(':memory:'); c.execute('create table t(a)'); print('mem ok')\nsqlite3.connect('rp_ok.db').close(); print('file ok')")
check("mem ok" in r and "file ok" in r, "run", "sqlite works in memory and inside the sandbox", first(r))
r, _ = rp("rp_thr", "import threading\nout = []\nt = threading.Thread(target=lambda: out.append(1)); t.start(); t.join(); print(out)")
check("[1]" in r, "run", "threads work", first(r))
r, _ = rp("rp_nt", "from collections import namedtuple\nfrom dataclasses import dataclass\nP = namedtuple('P', 'a b')\n@dataclass\nclass Q:\n    x: int = 1\nprint(P(1, 2), Q())")
check("P(a=1, b=2)" in r, "run", "namedtuple and dataclass work (stdlib imports are not over-blocked)", first(r))

# limits
r, dt = rp("rp_loop", "while True: pass")
check(r.startswith("[exit 124]") and "TIMED OUT" in r and dt < T.RUN_TIMEOUT_S + 4, "run", "infinite loop is killed by the timeout", f"{dt:.1f}s")
r, dt = rp("rp_sleep", "import time\ntime.sleep(60)")
check(r.startswith("[exit 124]") and dt < T.RUN_TIMEOUT_S + 4, "run", "sleep is killed by the timeout", f"{dt:.1f}s")
r, dt = rp("rp_flood", "while True: print('x' * 1000)")
check(len(r) < 12000 and "limit" in r.splitlines()[0] and dt < T.RUN_TIMEOUT_S + 4, "run", "endless output is stopped and capped", f"{len(r)} chars, {dt:.1f}s")
r, dt = rp("rp_mem", "x = []\nwhile True: x.append(bytearray(10**7))")
check(r.startswith("[exit 137]") and "KILLED" in r and dt < T.RUN_TIMEOUT_S + 4, "run", "runaway memory use is killed by the watchdog", f"{dt:.1f}s " + first(r))
check(not any(n.startswith(".run_") for n in os.listdir(SB)) and not (SB / "__pycache__").exists(),
      "run", "no temp folders or bytecode left behind")

# refusals of the command itself
check(T.run("run_python ../outside.txt").startswith("REFUSED"), "run", "outside path refused")
check(T.run("run_python _t.txt").startswith("REFUSED: run_python only runs .py"), "run", "non-.py refused")
check(T.run("run_python nope.py").startswith("ERROR: no such file"), "run", "missing file reported")
check(T.run("run_python").startswith("REFUSED: usage"), "run", "missing argument refused")
check(T.run("run_python guard.py").startswith("REFUSED: protected"), "run", "protected file cannot be run")
T.RUN_PYTHON = False
check("switched off" in T.run("run_python rp_ok.py"), "run", "RUN_PYTHON=0 switches it off")
T.RUN_PYTHON = True

# the agent loop: write -> run -> fix
scripted = iter([
    "NOTE: write\nCMD: write_file rp_agent.py\n```python\nprint(undefined_name)\n```",
    "NOTE: run it\nCMD: run_python rp_agent.py",
    "NOTE: fix\nCMD: patch_file rp_agent.py\n<<<<<<< SEARCH\nprint(undefined_name)\n=======\nprint('fixed')\n>>>>>>> REPLACE",
    "NOTE: run again\nCMD: run_python rp_agent.py",
    "NOTE: done\nDONE: it prints fixed",
])
calls = []
T.ask_model = lambda msgs: (calls.append(list(msgs)), next(scripted))[1]
with redirect_stdout(io.StringIO()):
    answer = T.agent("make rp_agent.py print something")
users = [[c for role, c in m if role == "user"][-1] for m in calls]
check("run_python rp_agent.py" in users[1], "agent", "after a write the model is told to run it")
check("It failed" in users[2] and "NameError" in users[2], "agent", "a failing run shows the error and says to fix it")
check("It ran OK" in users[4] and "fixed" in users[4], "agent", "a clean run says it can finish")
check(answer == "it prints fixed" and len(calls) == 5, "agent", "write, run, fix, run, DONE works", f"{len(calls)} calls")
check("run_python" in T.SYSTEM and "WORKFLOW" in T.SYSTEM, "agent", "SYSTEM prompt describes run_python")
T.PROTECTED = _saved_protected

# ---- refusal hints, audit log, base64 payloads, Gemini backend -------------------
import base64  # noqa: E402
for label, c in [("heredoc", "cat << 'EOF' > skill.py"), ("python3 -c", "python3 -c 'print(1)'"),
                 ("base64 -d", "base64 -d skill.b64"), ("echo redirect", "echo hi > skill.py"),
                 ("bad quote", "python3 -c 'print(\"it\\'s\")'")]:
    r = T.run(c)
    check(r.startswith("REFUSED:") and "write_file" in r and "run_python" in r, "hint", f"{label} refusal names write_file/run_python", first(r))
check("To create or change a file" not in T.run("rm -rf x"), "hint", "plain refusals stay short")
log = Path(os.environ["AUDIT_LOG"]).read_text()
check("heredoc" not in log and "cat << 'EOF'" in log and "python3 -c" in log and "rm -rf x" in log, "audit", "refused commands are logged")
check(T.AUDIT_LOG.resolve() in T.PROTECTED, "audit", "audit log is protected from the model")
check(T.run("write_file .." + "/x.txt\n```\nx\n```").startswith("REFUSED"), "audit", "write outside sandbox still refused")
check("never create or edit files with cat" in T.SYSTEM, "hint", "SYSTEM forbids file-writing tricks")

# base64-hidden payload: written with write_file, run with run_python. The runtime hook must still stop it.
evil = ("import os, subprocess\n"
        "for f in (lambda: open('/tmp/b64_escape.txt','w').write('x'),\n"
        "          lambda: subprocess.run(['id']),\n"
        "          lambda: os.system('id'),\n"
        "          lambda: open('/etc/hostname').read(),\n"
        "          lambda: os.remove('rp_victim.txt')):\n"
        "    try:\n        f(); print('ESCAPED')\n    except BaseException as e:\n        print('blocked', type(e).__name__)\n")
(SB / "rp_victim.txt").write_text("keep")
blob = base64.b64encode(evil.encode()).decode()
r, _ = rp("rp_b64", f"import base64\nexec(base64.b64decode('{blob}').decode())")
check("ESCAPED" not in r and r.count("blocked") == 5, "b64", "base64-hidden payload: all 5 escapes blocked at runtime", first(r))
check(not Path("/tmp/b64_escape.txt").exists() and (SB / "rp_victim.txt").read_text() == "keep", "b64", "no file written outside / deleted")

# Gemini backend: system prompt goes in system_instruction, roles are user/model, no real network used.
sent = {}
class _FM:
    def generate_content(self, model, contents, config):
        sent.update(model=model, roles=[c.role for c in contents], sys=config.system_instruction)
        return type("R", (), {"text": " CMD: ls "})()
class _FC:
    def __init__(self, api_key): self.models = _FM()
import types as _t  # noqa: E402
_g = _t.ModuleType("google"); _gg = _t.ModuleType("google.genai"); _ty = _t.ModuleType("google.genai.types")
_ty.Part = lambda text: _t.SimpleNamespace(text=text)
_ty.Content = lambda role, parts: _t.SimpleNamespace(role=role, parts=parts)
_ty.GenerateContentConfig = lambda system_instruction, temperature: _t.SimpleNamespace(system_instruction=system_instruction)
_gg.Client = _FC; _gg.types = _ty; _g.genai = _gg
_saved_mods = {k: sys.modules.get(k) for k in ("google", "google.genai", "google.genai.types")}
sys.modules.update({"google": _g, "google.genai": _gg, "google.genai.types": _ty})
_b, _k = T.BACKEND, os.environ.get("GEMINI_API_KEY")
T.BACKEND = "gemini"; os.environ["GEMINI_API_KEY"] = "test"
out = _REAL_ASK([("system", "SYS PROMPT"), ("user", "task"), ("assistant", "CMD: ls"), ("user", "out")])
check(out == "CMD: ls" and sent["sys"] == "SYS PROMPT" and sent["roles"] == ["user", "model", "user"],
      "gemini", "system prompt sent as system_instruction, roles user/model", str(sent))
os.environ.pop("GEMINI_API_KEY")
check(_REAL_ASK([("system", "s"), ("user", "u")]).startswith("ERROR: Failed to connect"), "gemini",
      "missing key stops the agent cleanly instead of looping")
T.BACKEND = _b
if _k is not None: os.environ["GEMINI_API_KEY"] = _k
for k, v in _saved_mods.items():
    if v is None: sys.modules.pop(k, None)
    else: sys.modules[k] = v

# a reply with a code fence but no CMD gets told how to save it
_msgs = []
_sc = iter(["Here is code:\n```python\nprint(1)\n```", "CMD: ls", "DONE: ok"])
T.ask_model = lambda m: (_msgs.append(list(m)), next(_sc))[1]
with redirect_stdout(io.StringIO()):
    T.agent("t")
check("write_file <name.py>" in _msgs[1][-1][1], "agent", "fence without CMD: told to use write_file")

# ---- DONE gate, patch hardening, indentation ----------------------------------------
T.REQUIRE_VERIFY = True
def play(replies, task="t"):
    it = iter(replies); seen = []
    T.ask_model = lambda m: (seen.append(list(m)), next(it, "DONE: (script ended)"))[1]
    buf = io.StringIO()
    with redirect_stdout(buf):
        ans = T.agent(task)
    return ans, buf.getvalue(), seen
def W(name, code): return f"CMD: write_file {name}\n```python\n{code}\n```"
def P(name, a, b): return f"CMD: patch_file {name}\n<<<<<<< SEARCH\n{a}\n=======\n{b}\n>>>>>>> REPLACE"

ans, out, _ = play([W("g1.py", "print(1/0)"), "DONE: it works"])
check(ans.startswith("(stopped: DONE was blocked 3 times") and "run_python" in out, "gate", "DONE right after write_file is blocked (never ran)", ans[:60])
ans, out, _ = play([W("g2.py", "print(1/0)"), "CMD: run_python g2.py", "DONE: it works"])
check("last run of g2.py failed" in out, "gate", "DONE after a FAILED run is blocked")
ans, out, _ = play([W("g3.py", "print(1/0)"), "CMD: run_python g3.py", P("g3.py", "print(1/0)", "print(1)"), "DONE: fixed"])
check("have not run it since" in out and "g3.py" in out, "gate", "DONE right after patch is blocked")
ans, out, _ = play([W("g4.py", "print(1/0)"), "CMD: run_python g4.py", P("g4.py", "print(1/0)", "print(1)"),
                    "CMD: run_python g4.py", "DONE: fixed, prints 1"])
check(ans == "fixed, prints 1", "gate", "write, run, patch, run, DONE is accepted", ans[:60])

# ---- 100-run csv_total: "CMD: DONE" was refused as a command and a correct run was aborted ----
ans, out, seen = play([W("bd.py", "print(6.5)"), "CMD: run_python bd.py", "NOTE: it prints 6.5\nCMD: DONE"])
check(ans == "it prints 6.5" and "command not allowed" not in out, "bareDONE", "bare CMD: DONE after a clean run ends the run with the NOTE as the answer", ans[:50])
ans, out, seen = play([W("bd2.py", "print(1)"), "NOTE: wrote it\nCMD: DONE"])
check(ans.startswith("(stopped: DONE was blocked") and "run_python" in out, "bareDONE", "bare CMD: DONE still goes through the DONE gate (never ran it)", ans[:60])
# ---- 100-run skill_v42: 4 runs answered "NOTE: stock.py has been written / DONE" as their ONLY reply ----
ans, out, seen = play(["NOTE: stock.py has been written.\nCMD: DONE: The code works."])
_u = [[c for r, c in m if r == "user"][-1] for m in seen]
check(ans.startswith("(stopped: DONE was blocked 3 times") and "have not run any command" in out, "workgate",
      "DONE as the very first reply is refused (nothing was done)", ans[:60])
ans, out, seen = play(["DONE: nothing to do", "CMD: ls", "DONE: listed the folder"])
check(ans == "listed the folder" and "have not run any command" in out, "workgate",
      "after one real command the same model can finish")
ans, out, seen = play(["CMD: rm -rf x", "DONE: tried"])
check("have not run any command" in out, "workgate", "a REFUSED command does not count as work")
T.REQUIRE_WORK_BEFORE_DONE = False
ans, out, seen = play(["DONE: just an answer"])
check(ans == "just an answer", "workgate", "the gate can be switched off (REQUIRE_WORK_BEFORE_DONE=0)")
T.REQUIRE_WORK_BEFORE_DONE = True
# ---- replace_def: replace one whole function/method/class by NAME (bugfix 0/100: the model inserted new code and left the old body behind) ----
def RD(name, code, path="rd.py"):
    return T.run(f"replace_def {path} {name}", "```python\n" + code + "\n```")
_src = ("import os\n\n\n"
        "def first(x):\n    return x\n\n\n"
        "def average(numbers):\n    total = 0\n    for n in numbers:\n        total += n\n    return total / len(numbers)\n\n\n"
        "class Stack:\n    def __init__(self):\n        self.items = []\n\n"
        "    def pop(self):\n        return self.items.pop()\n\n"
        "    @property\n    def size(self):\n        return len(self.items)\n\n\n"
        "def last(x):\n    return x[-1]\n")
(SB / "rd.py").write_text(_src)
_r = RD("average", "def average(numbers):\n    if not numbers:\n        return 0.0\n    return sum(numbers) / len(numbers)")
_new = (SB / "rd.py").read_text()
check(_r.startswith("[exit 0]") and "Successfully replaced average" in _r and "total += n" not in _new and "if not numbers" in _new,
      "replace_def", "a top-level function is replaced and its OLD body is gone", _r[:70])
check("def first(x):\n    return x\n\n\ndef average" in _new and "def last(x):" in _new and _new.startswith("import os\n\n\ndef first"),
      "replace_def", "the code around it (and the blank lines) is untouched")
_r = RD("Stack.pop", "def pop(self):\n    if not self.items:\n        raise IndexError('empty')\n    return self.items.pop()")
_new = (SB / "rd.py").read_text()
check(_r.startswith("[exit 0]") and "    def pop(self):\n        if not self.items:\n            raise IndexError('empty')\n        return self.items.pop()" in _new
      and "def __init__(self):\n        self.items = []" in _new, "replace_def", "a method is replaced, written at column 0, and indented to fit the class", _r[:70])
_r = RD("Stack.pop", "    def pop(self):\n        if not self.items:\n            raise IndexError('x')\n        return self.items.pop()")
check(_r.startswith("[exit 0]") and "IndexError('x')" in (SB / "rd.py").read_text() and "IndexError('empty')" not in (SB / "rd.py").read_text(),
      "replace_def", "a block that is already indented works too")
_r = RD("Stack.size", "def size(self):\n    return len(self.items) + 0")
_new = (SB / "rd.py").read_text()
check(_r.startswith("[exit 0]") and "@property" not in _new and "len(self.items) + 0" in _new, "replace_def",
      "the old decorator is part of the old definition and goes with it; the block says what stays")
_r = RD("Stack.size", "@property\ndef size(self):\n    return len(self.items)")
check(_r.startswith("[exit 0]") and "    @property\n    def size(self):\n        return len(self.items)\n" in (SB / "rd.py").read_text(), "replace_def",
      "a decorator in the block is kept")
_r = RD("Stack", "class Stack:\n    def __init__(self):\n        self.items = [0]")
_new = (SB / "rd.py").read_text()
check(_r.startswith("[exit 0]") and "self.items = [0]" in _new and "def pop" not in _new and "def last(x):" in _new, "replace_def", "a whole class can be replaced")
_before = (SB / "rd.py").read_text()
for label, name, code, frag in [
        ("unknown name", "nothing", "def nothing():\n    pass", "no def or class named nothing"),
        ("unknown method", "Stack.nope", "def nope(self):\n    pass", "no def or class named Stack.nope"),
        ("different name", "last", "def other(x):\n    return 1", "defines 'other' but you asked to replace 'last'"),
        ("two functions in the block", "last", "def last(x):\n    return 1\n\ndef extra():\n    pass", "exactly ONE complete def"),
        ("import in the block", "last", "import os\ndef last(x):\n    return 1", "exactly ONE complete def"),
        ("test code in the block", "last", "def last(x):\n    return 1\nprint(last([1]))", "exactly ONE complete def"),
        ("invalid python", "last", "def last(x):\nreturn 1", "not valid Python"),
        ("class vs function", "last", "class last:\n    pass", "the other kind"),
        ("same code", "last", "def last(x):\n    return x[-1]", "nothing would change")]:
    _r = RD(name, code)
    check(_r.startswith("REFUSED") and frag in _r and (SB / "rd.py").read_text() == _before, "replace_def",
          f"{label}: refused with a clear reason, file unchanged", _r[:90])
(SB / "rd_dup.py").write_text("def f():\n    return 1\n\n\ndef f():\n    return 2\n")
_r = RD("f", "def f():\n    return 3", "rd_dup.py")
check(_r.startswith("REFUSED") and "defined 2 times" in _r and "lines 1, 5" in _r, "replace_def", "a name defined twice is refused with both line numbers", _r[:90])
(SB / "rd_bad.py").write_text("def f(:\n    return 1\n")
check("syntax error" in RD("f", "def f():\n    return 1", "rd_bad.py"), "replace_def", "a file that already has a syntax error is not touched")
(SB / "rd_tab.py").write_text("class A:\n\tdef f(self):\n\t\treturn 1\n\n\tdef g(self):\n\t\treturn 2\n")
_tabsrc = (SB / "rd_tab.py").read_text()
_r = RD("A.f", "def f(self):\n    return 10", "rd_tab.py")
check(_r.startswith("REFUSED") and "syntax error" in _r and (SB / "rd_tab.py").read_text() == _tabsrc, "replace_def",
      "space-indented code spliced into a TAB-indented file is refused by the final syntax check, file unchanged", _r[:100])
(SB / "rd_async.py").write_text("import asyncio\n\nasync def run():\n    return 1\n")
check(RD("run", "async def run():\n    return 2", "rd_async.py").startswith("[exit 0]") and "return 2" in (SB / "rd_async.py").read_text(), "replace_def", "async def works")
(SB / "rd.txt").write_text("hello")
check(RD("x", "def x():\n    pass", "rd.txt").startswith("REFUSED") and "only works on .py" in RD("x", "def x():\n    pass", "rd.txt"), "replace_def", "only .py files")
check(RD("x", "def x():\n    pass", "nofile.py").startswith("REFUSED") and "does not exist" in RD("x", "def x():\n    pass", "nofile.py"), "replace_def", "a missing file is refused")
check(RD("x", "def x():\n    pass", ".." + "/outside.py").startswith("REFUSED"), "replace_def", "a path outside the sandbox is refused")
_g = T.PROTECTED.copy()
(SB / "guarded2.py").write_text("def x():\n    return 1\n"); T.PROTECTED.add((SB / "guarded2.py").resolve())
check(RD("x", "def x():\n    return 2", "guarded2.py").startswith("REFUSED") and "return 1" in (SB / "guarded2.py").read_text(), "replace_def", "a protected file cannot be changed")
T.PROTECTED.clear(); T.PROTECTED.update(_g)
check(T.run("replace_def rd.py last").startswith("REFUSED") and "no code received" in T.run("replace_def rd.py last"), "replace_def", "no ``` block: refused with where to put it")
check("usage: replace_def" in T.run("replace_def rd.py", "```python\ndef x():\n    pass\n```"), "replace_def", "missing name: usage shown")
check("usage: replace_def" in T.run("replace_def"), "replace_def", "no arguments: usage shown")
check(T.parse_reply("CMD: replace_def a.py f\n```python\ndef f():\n    pass\n```\nDONE: x")[0] == "cmd" and "replace_def" in T.BLOCK_CMDS, "replace_def", "replace_def is a block command for the reply parser")
check("replace_def" in T.SYSTEM and "Example replace_def" in T.SYSTEM and "replace_def" in T.run("zzz"), "replace_def", "the SYSTEM prompt and the allowed-commands message mention it")

# the real bugfix fixture, fixed with replace_def by a scripted model (read first, one edit per reply, run, DONE)
_fx = (ROOT.parent / "bench" / "tasks" / "bugfix" / "files" / "average.py") if (ROOT.parent / "bench").exists() else None
if _fx is None or not _fx.exists():
    _fx = Path(__file__).resolve().parent.parent / "bench" / "tasks" / "bugfix" / "files" / "average.py"
(SB / "average.py").write_text(_fx.read_text())
def RDc(name, code): return f"CMD: replace_def average.py {name}\n```python\n{code}\n```"
ans, out, seen = play(["CMD: replace_def average.py average\n```python\ndef average(numbers):\n    return 0.0\n```",
                       "CMD: read_file average.py",
                       RDc("average", "def average(numbers):\n    if not numbers:\n        return 0.0\n    return sum(numbers) / len(numbers)"),
                       RDc("median", "def median(numbers):\n    s = sorted(numbers)\n    mid = len(s) // 2\n    if len(s) % 2 == 0:\n        return (s[mid - 1] + s[mid]) / 2\n    return s[mid]"),
                       "DONE: fixed",
                       "CMD: run_python average.py", "DONE: prints 2.5, 2.5, 0.0"])
_run = subprocess.run([sys.executable, "-I", str(SB / "average.py")], capture_output=True, text=True, timeout=20)
check("have not looked at average.py" in out, "replace_def", "the read-before-edit gate applies to replace_def as well")
check(_run.stdout == "2.5\n2.5\n0.0\n" and "total += n" not in (SB / "average.py").read_text() and "s.sort()" not in (SB / "average.py").read_text(),
      "replace_def", "bugfix fixture: two replace_def commands fix all three bugs and the file prints 2.5 / 2.5 / 0.0", repr(_run.stdout[:40]))
check("have not run it since" in out and ans == "prints 2.5, 2.5, 0.0", "replace_def", "DONE right after replace_def is blocked until run_python")
# ---- small bugfix screen (replace_def): the invented tail of a refused edit stayed in history; 75 short NOTE lines in one reply ----
_ed = ("NOTE: fix median\nCMD: replace_def average.py median\n```python\ndef median(numbers):\n    return 1\n```\n"
       "NOTE: The median function is now correctly handling even numbers of items.\nCMD: run_python average.py\n2.5\nDONE: fixed")
_h = T._clean_reply(_ed, "cmd", "replace_def average.py median", ["fix median"])
check(_h.endswith("```") and "now correctly handling" not in _h and "DONE" not in _h and "def median" in _h and "NOTE: fix median" in _h,
      "tailcut", "history keeps a replace_def reply only up to the end of its block (invented NOTE/CMD/DONE dropped)", _h[-60:])
_hw = T._clean_reply("CMD: write_file a.py\n```python\nx = 1\n```\nDONE: wrote it", "cmd", "write_file a.py", [])
check(_hw == "CMD: write_file a.py\n```python\nx = 1\n```", "tailcut", "same for write_file")
_hp = T._clean_reply("CMD: patch_file a.py\n<<<<<<< SEARCH\na\n=======\nb\n>>>>>>> REPLACE\nmore code\nDONE: ok", "cmd", "patch_file a.py", [])
check(_hp.endswith(">>>>>>> REPLACE") and "more code" not in _hp, "tailcut", "same for patch_file")
_hm = T._clean_reply("CMD: write_file a.md\n```md\nhere:\n```python\nx\n```\nend\n```\nDONE: ok", "cmd", "write_file a.md", [])
check("end\n```" in _hm and "DONE" not in _hm, "tailcut", "inner fences in file content are kept, only the tail after the real closing fence goes")
_hu = "CMD: write_file a.py\n```python\nx = 1"
check(T._clean_reply(_hu, "cmd", "write_file a.py", []) == _hu, "tailcut", "an unclosed block is left as it was (nothing to cut)")
# end to end: after a refused first edit the model's next prompt must not contain its invented claims
ans, out, seen = play([_ed.replace("average.py", "nofile_x.py"), "CMD: ls", "DONE: listed"])
_hist = " ".join(c for r, c in seen[1] if r == "assistant")
check("now correctly handling" not in _hist and "DONE: fixed" not in _hist, "tailcut", "the model never sees its own invented claim again in the next prompt")
_flood = "NOTE: a\nCMD: run_python x.py\n" + "\n".join(f"NOTE: read_file average.py {i} 10" for i in range(1, 80))
check(T._runaway_note(_flood), "noteflood", "many short NOTE lines in one reply are detected as a runaway")
check(not T._runaway_note("NOTE: a\nNOTE: b\nCMD: ls"), "noteflood", "two or three NOTE lines are normal")
check(not T._runaway_note("CMD: write_file a.py\n```python\n" + "\n".join(f"NOTE: line {i}" for i in range(40)) + "\n"), "noteflood",
      "NOTE-looking lines inside a code block are file content")
check(not T._runaway_note("CMD: write_file a.py\n```python\n" + "\n".join(f"NOTE: line {i}" for i in range(40)) + "\n```\nNOTE: done"), "noteflood",
      "40 NOTE-looking lines inside a CLOSED code block are not counted")
_pc = T.parse_reply(_flood)
check(_pc[0] == "cmd" and _pc[1] == "run_python x.py" and len(_pc[3]) <= T.NOTE_MAX_LINES, "noteflood", "a flooded reply still parses, with at most NOTE_MAX_LINES notes", str(len(_pc[3])))
_k = T._cap_notes("CMD: write_file a.py\n```python\n" + "\n".join(f"NOTE: n{i}" for i in range(10)) + "\n```")
check(_k.count("NOTE: n") == 10, "noteflood", "NOTE lines inside a code block are never dropped")
_cnt = [0]
def _sse2():
    yield 'data: {"choices":[{"delta":{"content":"NOTE: a\\nCMD: run_python x.py\\n"}}]}'
    for i in range(4000):
        _cnt[0] += 1
        yield 'data: {"choices":[{"delta":{"content":"NOTE: read_file average.py %d 10\\n"}}]}' % i
_tx = T._read_sse(_sse2(), show_progress=False)[0]
check(_cnt[0] < 200 and _tx.startswith("NOTE: a"), "noteflood", "the stream is stopped early on a NOTE flood", f"read {_cnt[0]} of 4000 pieces")
# ---- 10-run bugfix report (zip 15): patch_file with SEARCH == REPLACE == a def line and the new function elsewhere; a repeated edit ----
(SB / "hd.py").write_text("class Box:\n    def size(self):\n        return 1\n\n\ndef median(numbers):\n    s = numbers\n    return s\n\n\ndef dup():\n    pass\n\n\ndef dup():\n    pass\n")
_ident = "<<<<<<< SEARCH\ndef median(numbers):\n=======\ndef median(numbers):\n>>>>>>> REPLACE\n"
_body = "```python\ndef median(numbers):\n    return 1\n```\n"
_hd0 = (SB / "hd.py").read_text()
_r = T.run("patch_file hd.py", _ident + _body)
check(_r.startswith("REFUSED") and "INSIDE the block" in _r and "CMD: replace_def hd.py median" in _r and (SB / "hd.py").read_text() == _hd0,
      "rdhint", "identical def line + code after it: refusal names the exact replace_def command", _r[-130:])
_r = T.run("patch_file hd.py", _ident)
check(_r.startswith("REFUSED") and "nothing would change" in _r and "CMD: replace_def hd.py median" in _r and "INSIDE the block" not in _r,
      "rdhint", "identical def line alone: plain refusal plus the replace_def command")
_r = T.run("patch_file hd.py", _ident.replace("median(numbers)", "size(self)"))
check("CMD: replace_def hd.py Box.size" in _r, "rdhint", "a method gets its Class.method name in the hint", _r[-90:])
_r = T.run("patch_file hd.py", _ident.replace("median(numbers)", "dup()"))
check(_r.startswith("REFUSED") and "replace_def" not in _r, "rdhint", "a name defined twice gets no hint (it would be ambiguous)")
_r = T.run("patch_file hd.py", "<<<<<<< SEARCH\n    s = numbers\n=======\n    s = numbers\n>>>>>>> REPLACE\n")
check(_r.startswith("REFUSED") and "replace_def" not in _r, "rdhint", "an identical NON-def line gets no hint")
_r = T.run("patch_file hd.py", _ident.replace("median(numbers)", "nothere(x)"))
check(_r.startswith("REFUSED") and "replace_def" not in _r, "rdhint", "an unknown function name gets no hint")
(SB / "rp.py").write_text("x = 1\n")
_ed2 = P("rp.py", "x = 1", "x = 2")
ans, out, seen = play(["CMD: read_file rp.py", _ed2, _ed2, "DONE: x is 2"])
_u = [[c for r, c in m if r == "user"][-1] for m in seen]
check("already applied earlier" in _u[3] and "DIFFERENT problem" in _u[3] and "If the task is finished" not in _u[3], "rdhint",
      "repeating an edit that already worked: the refusal says it is already applied (not 'the task is finished')", _u[3][:110])

# ---- run 8 of the wordcount retest: invented follow-up steps, and a run that printed nothing ----
check(T._ignored_tail("```python\nx=1\n```\nDONE: ok"), "tail", "DONE after a command block is detected")
check(T._ignored_tail("\nNOTE: a\nCMD: check_file x.py\n"), "tail", "a second CMD is detected")
check(not T._ignored_tail("```python\nCMD: not a command, file content\nDONE: nor this\n```\n"), "tail", "CMD:/DONE: inside a code block is file content")
check(not T._ignored_tail("<<<<<<< SEARCH\nCMD: x\n=======\nDONE: y\n>>>>>>> REPLACE\n"), "tail", "CMD:/DONE: inside a patch block is file content")
check(not T._ignored_tail("NOTE: just a note\n"), "tail", "a NOTE after the command is not an ignored command")
ans, out, seen = play([W("t1.py", "print('hi')") + "\n\nNOTE: next\nCMD: run_python t1.py\n```\nhi\n```\nDONE: it works",
                       "CMD: run_python t1.py", "DONE: printed hi"])
_u = [[c for r, c in m if r == "user"][-1] for m in seen]
check("Only your FIRST command was run" in _u[1], "tail", "the model is told that the rest of its reply was ignored", _u[1][-120:])
check("Only your FIRST command was run" not in _u[2] and ans == "printed hi", "tail", "a clean reply gets no such warning")
ans, out, seen = play([W("t2.py", "x = 1"), "CMD: run_python t2.py", "CMD: run_python t2.py", "DONE: ok"])
_u = [[c for r, c in m if r == "user"][-1] for m in seen]
check("PRINTED NOTHING" in _u[2] and "It ran OK" not in _u[2], "tail", "a run with no output does not say 'It ran OK'", _u[2][-130:])
ans, out, seen = play([W("t3.py", "print('x')"), "CMD: run_python t3.py", "DONE: printed x"])
_u = [[c for r, c in m if r == "user"][-1] for m in seen]
check("It ran OK" in _u[2] and "PRINTED NOTHING" not in _u[2], "tail", "a run with output still says 'It ran OK'")

# ---- bugfix retest (0/5): the model patched a file it never read, from invented lines ----
_fix = "def average(numbers):\n    return sum(numbers) / len(numbers)\n"
def _patch(a_, b_): return P("rb.py", a_, b_)
(SB / "rb.py").write_text(_fix)
ans, out, seen = play([_patch("def average(numbers):", "def average(numbers):\n    if not numbers:\n        return 0.0"),
                       "CMD: read_file rb.py"])
_u = [[c for r, c in m if r == "user"][-1] for m in seen]
check("have not looked at rb.py" in _u[1] and "NOT applied" in _u[1] and "   2 |     return sum(numbers) / len(numbers)" in _u[1]
      and (SB / "rb.py").read_text() == _fix,
      "readgate", "patching a file never read is refused AND the refusal shows the file's real numbered lines; file unchanged", _u[1][:90])
(SB / "rb.py").write_text(_fix)
_e = _patch("    return sum(numbers) / len(numbers)", "    if not numbers:\n        return 0.0\n    return sum(numbers) / len(numbers)")
ans, out, seen = play([_e, _e])
check(out.count("have not looked at rb.py") == 1 and "if not numbers" in (SB / "rb.py").read_text(), "readgate",
      "after the refusal showed the file, the SAME edit sent again goes through (no second read needed)")
(SB / "rb.py").write_text(_fix)
ans, out, seen = play(["CMD: replace_def rb.py average\n```python\ndef average(numbers):\n    return 0.0\n```"] * 3)
check(out.count("have not looked at rb.py") == 1 and "return 0.0" in (SB / "rb.py").read_text(), "readgate", "same for replace_def")
(SB / "rb.py").write_text(_fix)
ans, out, seen = play(["CMD: read_file rb.py", _patch("    return sum(numbers) / len(numbers)", "    if not numbers:\n        return 0.0\n    return sum(numbers) / len(numbers)")])
check("if not numbers" in (SB / "rb.py").read_text() and "have not looked" not in out, "readgate", "after a real read_file the patch applies")
(SB / "rb.py").write_text(_fix)
ans, out, seen = play(["CMD: cat rb.py", _patch("def average(numbers):", "def mean(numbers):")])
check("def mean" in (SB / "rb.py").read_text(), "readgate", "cat counts as looking at the file")
(SB / "rb.py").write_text(_fix)
ans, out, seen = play(["CMD: run_python rb.py", _patch("def average(numbers):", "def mean(numbers):")])
check("def mean" in (SB / "rb.py").read_text(), "readgate", "run_python counts as looking at the file")
ans, out, seen = play([W("rw.py", "def f():\n    return 1"), P("rw.py", "return 1", "return 2")])
check("return 2" in (SB / "rw.py").read_text() and "have not looked" not in out, "readgate", "a file the model wrote itself needs no read first")
ans, out, seen = play([P("nofile.py", "a", "b")])
check("have not looked" not in out and "does not exist" in out, "readgate", "a missing file gets the normal message, not the gate")
T.REQUIRE_READ_BEFORE_PATCH = False
(SB / "rb.py").write_text(_fix)
ans, out, seen = play([_patch("def average(numbers):", "def mean(numbers):")])
check("def mean" in (SB / "rb.py").read_text(), "readgate", "the gate can be switched off (REQUIRE_READ_BEFORE_PATCH=0)")
T.REQUIRE_READ_BEFORE_PATCH = True
(SB / "g5.py").write_text("print('a')\n")
ans, out, _ = play(["CMD: patch_file g5.py\n<<<<<<< SEARCH\nprint('zzz')\n=======\nprint('b')\n>>>>>>> REPLACE", "DONE: patched"])
check("never applied" in out and "patch_file g5.py" in out, "gate", "a REFUSED patch that was never redone blocks DONE")
ans, out, _ = play([W("h_helper.py", "def f():\n    return 1/0"),
                    W("h_main.py", "import h_helper\nprint(h_helper.f())"),
                    "CMD: run_python h_main.py",
                    P("h_helper.py", "return 1/0", "return 7"),
                    "CMD: run_python h_main.py", "DONE: ok"])
check(ans == "ok", "gate", "running main.py verifies the helper module it imports", out[-160:])
ans, out, _ = play([W("g6.txt", "notes"), "DONE: wrote notes"])
check(ans == "wrote notes", "gate", "non-Python files are not gated")
T.REQUIRE_VERIFY = False
ans, out, _ = play([W("g7.py", "print(1)"), "DONE: x"])
check(ans == "x", "gate", "REQUIRE_VERIFY=0 turns the gate off")
T.REQUIRE_VERIFY = True

# strict mode: no patching a file that was never run (unless the static check listed problems)
T.REQUIRE_RUN_BEFORE_PATCH = True
ans, out, _ = play([W("s1.py", "print('a')"), P("s1.py", "print('a')", "print('b')"), "CMD: run_python s1.py",
                    P("s1.py", "print('a')", "print('b')"), "CMD: run_python s1.py", "DONE: ok"])
check("run_python s1.py first" in out and ans == "ok", "gate", "strict mode: patch before first run is refused, later allowed", out[-120:])
ans, out, _ = play([W("s2.py", "class A:\n    def f(self):\n        pass"), P("s2.py", "        pass", "        return 1"),
                    "CMD: run_python s2.py", "DONE: ok"])
check("run_python s2.py first" not in out, "gate", "strict mode: a fix the static check asked for is not locked out")
T.REQUIRE_RUN_BEFORE_PATCH = False

# patch_file: no-ops and indentation
(SB / "i1.py").write_text("class O:\n    def p(self):\n        total = self.c()\n        print(total)\n")
r = T.run("patch_file i1.py", "<<<<<<< SEARCH\n        total = self.c()\n=======\n        total = self.c()\n>>>>>>> REPLACE")
check(r.startswith("REFUSED") and "identical" in r, "patch", "SEARCH == REPLACE is refused, not 'success'", first(r))
r = T.run("patch_file i1.py", "<<<<<<< SEARCH\ntotal = self.c()\n=======\nif self.o:\n    total = self.c()\nelse:\n    print('none')\n>>>>>>> REPLACE")
src = (SB / "i1.py").read_text()
check(r.startswith("[exit 0]") and "adjusted" in r and "        if self.o:\n            total = self.c()\n        else:\n            print('none')\n        print(total)" in src
      and "no problems" in r, "patch", "unindented multi-line REPLACE gets the file's indentation (the Prompt #2 failure)", r[-120:] + repr(src[-160:]))
(SB / "i2.py").write_text("def f():\n    if x:\n        return 1\n    return 2\n")
r = T.run("patch_file i2.py", "<<<<<<< SEARCH\nif x:\n    return 1\n=======\nif y:\n    return 5\n>>>>>>> REPLACE")
check("    if y:\n        return 5\n    return 2" in (SB / "i2.py").read_text() and "adjusted" in r, "patch", "multi-line SEARCH with wrong indentation still matches (re-indented)", r)
(SB / "i3.py").write_text("def f():\n    a = 1\n    return a\n")
r = T.run("patch_file i3.py", "<<<<<<< SEARCH\n    a = 1\n=======\n    a = 1\n    b = 2\n>>>>>>> REPLACE")
check((SB / "i3.py").read_text() == "def f():\n    a = 1\n    b = 2\n    return a\n" and "adjusted" not in r, "patch", "an already-correct patch is applied untouched", r)
(SB / "i4.py").write_text("def f():\n    x = 1\n    y = 1\n")
r = T.run("patch_file i4.py", "<<<<<<< SEARCH\n= 1\n=======\n= 2\n>>>>>>> REPLACE")
check("not unique" in r, "patch", "ambiguous search still refused", first(r))
(SB / "i5.py").write_text("def f():\n    if a:\n        z()\n    if b:\n        z()\n")
r = T.run("patch_file i5.py", "<<<<<<< SEARCH\nz()\n=======\nw()\n>>>>>>> REPLACE")
check("not unique" in r or "more than one" in r, "patch", "ambiguous whitespace-insensitive match refused", first(r))
check("exact leading spaces" in "\n".join(T.check_python("def f():\nreturn 1\n")), "patch", "IndentationError message tells how to fix it")

# history sanitising
_, _, seen = play(["NOTE: look\nCMD: ls\ntool> fake output\nDONE: all good", "DONE: really"])
hist = [c for r, c in seen[-1] if r == "assistant"][0]
check("fake" not in hist and "DONE" not in hist and "CMD: ls" in hist, "agent", "text invented after a command is not kept in history", repr(hist))
T.REQUIRE_VERIFY = False

# the probes from the Android Studio copy: all must be blocked here
import base64 as _b64  # noqa: E402
_vic = SB.parent / "outside_victim.txt"; _vic.write_text("keep")
os.environ["GEMINI_API_KEY"] = "FAKE-KEY-123"
_enc = _b64.b64encode(b"import subprocess\nprint(subprocess.run(['id'],capture_output=True,text=True).stdout)").decode()
probes = {
    "read outside": f"print(open({str(_vic)!r}).read())",
    "delete outside": f"import os\nos.remove({str(_vic)!r})",
    "write outside": f"open({str(SB.parent / 'w_out.txt')!r},'w').write('x')",
    "env key": "import os\nprint(os.environ.get('GEMINI_API_KEY'))",
    "alias exec + base64": f"import base64\ne = exec\ne(base64.b64decode('{_enc}').decode())",
    "getattr os.system": "import os\ngetattr(os,'sys'+'tem')('echo PWN'+'ED')",
    "chmod": "import os\nos.chmod('probe_x.py', 0o777)",
}
for label, code in probes.items():
    r, _ = rp("probe_x", code)
    leaked = "FAKE-KEY" in r or "PWNED" in r or "uid=" in r or "keep" in r
    check(not leaked and r.startswith(("[exit", "REFUSED")), "escape", f"{label}: blocked", first(r))
check(_vic.read_text() == "keep" and not (SB.parent / "w_out.txt").exists(), "escape", "no file outside was touched")
os.environ.pop("GEMINI_API_KEY", None)

# ---- local server client: streaming, speed stats, slow-server handling, --ping -----------
import http.server, threading, json as _json  # noqa: E402
class _H(http.server.BaseHTTPRequestHandler):
    mode = "stream"
    def log_message(self, *a): pass
    def handle(self):
        try: super().handle()
        except (BrokenPipeError, ConnectionResetError): pass
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); body = _json.loads(self.rfile.read(n))
        _H.last = body
        if _H.mode == "json":
            data = _json.dumps({"choices": [{"message": {"content": "CMD: ls"}}]}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
        self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self.end_headers()
        pieces = ["CMD", ":", " ls"] if _H.mode == "stream" else ["x"] * 50
        for i, piece in enumerate(pieces):
            self.wfile.write(("data: " + _json.dumps({"choices": [{"delta": {"content": piece}}]}) + "\n\n").encode()); self.wfile.flush()
            if _H.mode == "crawl": time.sleep(0.2)
        self.wfile.write(("data: " + _json.dumps({"choices": [], "timings": {"prompt_n": 900, "prompt_per_second": 3.06,
                          "predicted_n": 3, "predicted_per_second": 0.5}}) + "\n\ndata: [DONE]\n\n").encode())
_srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _H); threading.Thread(target=_srv.serve_forever, daemon=True).start()
_old = (T.SERVER_URL, T.LLAMA_TIMEOUT, T.LLAMA_TOTAL_TIMEOUT)
T.SERVER_URL = f"http://127.0.0.1:{_srv.server_address[1]}/v1/chat/completions"
_H.mode = "stream"
out = T._ask_local([("system", "s"), ("user", "u")])
check(out == "CMD: ls" and _H.last.get("stream") is True, "local", "streamed reply is assembled", out)
check("prompt 900 tok @ 3.1 tok/s" in T.LAST_STATS and "generated 3 tok @ 0.50 tok/s" in T.LAST_STATS, "local", "server timings are reported", T.LAST_STATS)
_H.mode = "json"
check(T._ask_local([("user", "u")]) == "CMD: ls", "local", "a server that ignores stream=true still works")
_H.mode = "crawl"; T.LLAMA_TOTAL_TIMEOUT = 1
out = T._ask_local([("user", "u")])
check(out.startswith("ERROR: Failed to connect") and "too slow" in out and "--ping" in out, "local", "a crawling server stops with a clear message", out[:120])
T.LLAMA_TOTAL_TIMEOUT = 1800; _H.mode = "stream"
r = subprocess.run([sys.executable, "sandbox_tool.py", "--ping"], cwd=shadow, capture_output=True, text=True,
                   env={**os.environ, "LLAMA_URL": T.SERVER_URL, "SANDBOX_DIR": str(shadow)})
check("server replied" in r.stdout and "tok/s" in r.stdout and "CMD: ls" in r.stdout, "local", "--ping reports speed", r.stdout[:140] + r.stderr[:80])
r = subprocess.run([sys.executable, "sandbox_tool.py", "--agent", "hi"], cwd=shadow, capture_output=True, text=True,
                   env={**os.environ, "LLAMA_URL": T.SERVER_URL, "SANDBOX_DIR": str(shadow), "REQUIRE_VERIFY": "0"})
check("[llm]" in r.stdout and "prompt 900 tok" in r.stdout, "local", "the agent prints speed after each model reply", r.stdout[:200])
T.SERVER_URL, T.LLAMA_TIMEOUT, T.LLAMA_TOTAL_TIMEOUT = _old
_srv.shutdown()

# server replies that used to give "Expecting value: line 1 column 1 (char 0)"
_ok = _json.dumps({"choices": [{"delta": {"content": "CMD: ls"}}]}).encode()
_plain = _json.dumps({"choices": [{"message": {"content": "CMD: ls"}}], "timings": {"prompt_n": 5, "prompt_per_second": 5.0, "predicted_n": 2, "predicted_per_second": 4.7}}).encode()
class _H2(http.server.BaseHTTPRequestHandler):
    variants = {
        "empty data line": (b"data: \n\ndata: " + _ok + b"\n\ndata: [DONE]\n\n", "text/event-stream"),
        "SSE under json type": (b"data: " + _ok + b"\n\ndata: [DONE]\n\n", "application/json"),
        "keepalive comment": (b": keep-alive\n\ndata: " + _ok + b"\n\ndata: [DONE]\n\n", "text/event-stream"),
        "CRLF lines": (b"data: " + _ok + b"\r\n\r\ndata: [DONE]\r\n\r\n", "text/event-stream"),
        "junk chunk": (b"data: not-json\n\ndata: " + _ok + b"\n\ndata: [DONE]\n\n", "text/event-stream"),
        "empty body": (b"", "application/json"),
        "garbage body": (b"<html>oops</html>", "text/html"),
    }
    def log_message(self, *a): pass
    def handle(self):
        try: super().handle()
        except (BrokenPipeError, ConnectionResetError): pass
    def do_POST(self):
        req = _json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
        _H2.calls.append(bool(req.get("stream")))
        body, ct = _H2.variants[_H2.mode] if req.get("stream") or _H2.mode in ("garbage body",) else (_plain, "application/json")
        if _H2.mode == "empty body" and req.get("stream"): body, ct = b"", "application/json"
        self.send_response(200); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(body)))
        self.end_headers(); self.wfile.write(body)
_srv2 = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _H2); threading.Thread(target=_srv2.serve_forever, daemon=True).start()
T.SERVER_URL = f"http://127.0.0.1:{_srv2.server_address[1]}/v1/chat/completions"
for mode in ("empty data line", "SSE under json type", "keepalive comment", "CRLF lines", "junk chunk", "empty body"):
    _H2.mode, _H2.calls = mode, []
    out = T._ask_local([("user", "u")])
    check(out == "CMD: ls", "local", f"server reply variant readable: {mode}", f"{out[:80]} calls={_H2.calls}")
_H2.mode, _H2.calls = "empty body", []; T._ask_local([("user", "u")])
check(_H2.calls == [True, False], "local", "unreadable stream is retried once without streaming", str(_H2.calls))
_H2.mode = "garbage body"; out = T._ask_local([("user", "u")], stream=False)
check(out.startswith("ERROR: Failed to connect") and "oops" in out, "local", "a non-JSON reply says what the server sent", out[:100])
T.LLAMA_STREAM = False; _H2.mode, _H2.calls = "empty data line", []
check(T._ask_local([("user", "u")]) == "CMD: ls" and _H2.calls == [False], "local", "LLAMA_STREAM=0 sends a plain request")
T.LLAMA_STREAM = True
_srv2.shutdown()

# ---- CLI entry point: one final line only, and the chmod reminder -----------
r = subprocess.run([sys.executable, "sandbox_tool.py", "--agent", "hi"], cwd=shadow,
                   capture_output=True, text=True, env={**os.environ, "SANDBOX_DIR": str(shadow)})
check(r.stdout.count("final>") == 1 and "(stopped: ERROR: Failed to connect" in r.stdout,
      "cli", "stopped runs print one final> line")
check("chmod 444 sandbox_tool.py" in r.stderr, "cli", "writable guard file inside sandbox is flagged")
os.chmod(shadow / "sandbox_tool.py", 0o444)
r = subprocess.run([sys.executable, "sandbox_tool.py", "--agent", "hi"], cwd=shadow,
                   capture_output=True, text=True, env={**os.environ, "SANDBOX_DIR": str(shadow)})
check("[warn]" not in r.stderr, "cli", "no warning once it is chmod 444")

# ---- transcript dump for the testkit (AGENT_TRANSCRIPT) -------------------------------------
import json as _json
_tp = ROOT / "transcript_test.json"
_old_ask = T.ask_model
T.ask_model = lambda msgs: "NOTE: done\nDONE: all good"
os.environ["AGENT_TRANSCRIPT"] = str(_tp)
T.REQUIRE_WORK_BEFORE_DONE = False   # this test is about the transcript file, not the DONE gate
_res = T.agent("do a thing")
T.REQUIRE_WORK_BEFORE_DONE = True
del os.environ["AGENT_TRANSCRIPT"]
_tr = _json.loads(_tp.read_text()) if _tp.exists() else {}
check(_res == "all good" and _tr.get("stopped") is False and _tr.get("result") == "all good"
      and [m["role"] for m in _tr.get("messages", [])] == ["system", "user", "assistant"]
      and _tr["messages"][1]["content"] == "do a thing", "transcript", "AGENT_TRANSCRIPT saves the conversation as JSON")
T.ask_model = lambda msgs: "ERROR: Failed to connect to local llama-server: down"
os.environ["AGENT_TRANSCRIPT"] = str(_tp)
T.agent("x")
del os.environ["AGENT_TRANSCRIPT"]
check(_json.loads(_tp.read_text()).get("stopped") is True, "transcript", "a stopped run is saved with stopped=true")
T.agent("no env set, nothing written")
T.ask_model = _old_ask
r = subprocess.run([sys.executable, "-c", "import os;print(int(os.environ.get('AGENT_MAX_STEPS') or 10))"],
                   capture_output=True, text=True, env={**os.environ, "AGENT_MAX_STEPS": "4"})
check(r.stdout.strip() == "4" and "AGENT_MAX_STEPS" in open(HERE.parent / "src" / "sandbox_tool.py").read(), "transcript", "AGENT_MAX_STEPS wiring exists in the CLI (source check only; bench.py exercises it)")

# ---- packaging: no machine-specific paths, safe defaults ----------------------------------------
SRC = HERE.parent / "src" / "sandbox_tool.py"
_src = SRC.read_text()
check(not any(bad_s in _src for bad_s in ("/data/data", "OKX-Terminal", "/home/claude", "/tmp/claude")),
      "package", "no machine-specific paths or personal details in the source")
_cwd = ROOT / "fresh_cwd"
_cwd.mkdir()
_clean = {k: v for k, v in os.environ.items() if k not in ("SANDBOX_DIR", "AUDIT_LOG", "PREFIX")}
_home = ROOT / "fakehome"
(_home / "proj").mkdir(parents=True)


def _cli(*args, cwd=_cwd, **env):
    return subprocess.run([sys.executable, str(SRC), *args], cwd=cwd, capture_output=True, text=True,
                          env={**_clean, "HOME": str(_home), **env})


r = _cli("--version")
check(r.returncode == 0 and r.stdout.startswith("sandbox-tool "), "package", "--version works", r.stdout + r.stderr)
r = _cli("--help")
check(r.returncode == 0 and "--agent" in r.stdout and "SANDBOX_DIR" in r.stdout, "package", "--help explains usage")
r = _cli("ls")
check(r.returncode == 0 and (_cwd / "sandbox").is_dir() and "sandbox_tool.py" not in r.stdout,
      "package", "with no SANDBOX_DIR the sandbox is ./sandbox (created), never the folder holding the tool", r.stdout + r.stderr)
check(not (_cwd / "sandbox" / "sandbox_tool.py").exists(), "package", "default sandbox does not contain the tool file")
r = _cli("ls", SANDBOX_DIR=str(_home))
check(r.returncode == 2 and "too broad" in r.stderr, "package", "your home folder is refused as a sandbox", r.stderr)
r = _cli("ls", SANDBOX_DIR="/")
check(r.returncode == 2 and "too broad" in r.stderr, "package", "the filesystem root is refused as a sandbox", r.stderr)
r = _cli("ls", SANDBOX_DIR=str(_home / "proj"))
check(r.returncode == 0, "package", "a subfolder of home is fine", r.stderr)
r = _cli("ls", SANDBOX_DIR=str(_home / "typo"))
check(r.returncode == 2 and "not an existing folder" in r.stderr and not (_home / "typo").exists(),
      "package", "a SANDBOX_DIR typo stops instead of creating a stray folder", r.stderr)
_probe = ("import sandbox_tool as T, json; print(json.dumps([str(T.AUDIT_LOG), T.SAFE_PATH, str(T.SANDBOX)]))")
r = subprocess.run([sys.executable, "-c", _probe], capture_output=True, text=True, cwd=_cwd,
                   env={**_clean, "PYTHONPATH": str(SRC.parent), "SANDBOX_DIR": str(_home / "proj")})
_a, _p, _sbx = __import__("json").loads(r.stdout)
check(_a == str(_home / "proj.refused.log"), "package", "audit log defaults to <sandbox>.refused.log next to the sandbox", _a)
_allowed = {"/usr/local/bin", "/usr/bin", "/bin", os.path.dirname(os.path.realpath(sys.executable))}
check(set(_p.split(os.pathsep)) <= _allowed and all(os.path.isdir(x) for x in _p.split(os.pathsep)),
      "package", "child PATH is only real system folders plus the running Python's folder", _p)
(_home / "fakeprefix" / "bin").mkdir(parents=True)
r = subprocess.run([sys.executable, "-c", _probe], capture_output=True, text=True, cwd=_cwd,
                   env={**_clean, "PYTHONPATH": str(SRC.parent), "SANDBOX_DIR": str(_home / "proj"), "PREFIX": str(_home / "fakeprefix")})
check(str(_home / "fakeprefix" / "bin") in __import__("json").loads(r.stdout)[1], "package", "$PREFIX/bin (Termux) is added to the child PATH when set")

shutil.rmtree(ROOT, ignore_errors=True)
print("\nALL OK" if not bad else f"\n{bad} FAILURES")
sys.exit(1 if bad else 0)
